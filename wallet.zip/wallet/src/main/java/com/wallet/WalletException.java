package com.wallet;

public class WalletException extends Exception{
    public WalletException(String msg){
        super(msg);
    }
}
